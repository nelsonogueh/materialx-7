package com.material.components.model;

import android.graphics.drawable.Drawable;

public class Image {

    public int image;
    public Drawable imageDrw;
    public String name;
    public String brief;
    public Integer counter = null;

}
